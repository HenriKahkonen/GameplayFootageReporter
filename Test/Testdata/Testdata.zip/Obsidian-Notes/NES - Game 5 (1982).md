---
year: 1982
Genret:
  - "[[Räiskintä (FPS) -pelit]]"
  - "[[Lisäosat]]"
tags:
  - Peli
Alusta(t):
  - "[[PC]]"
  - Useilla alustoilla
Playtime_hrs:
Playtime_mins:
Pelisarja: "[[Doom-pelisarja]]"
Kehittäjä(t):
  - "[[id Software]]"
Julkaisija(t):
Rating: 3,5
Play_Status: "[[Status - Completed]]"
---
---

**Linkit:**
- [[]]


---

## Yleisesti

- Kovempi meno kuin Doom3, enemmän toimintaa
- Uusia vihuja
