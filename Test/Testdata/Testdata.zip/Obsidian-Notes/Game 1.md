---
year: 1822
Genret: 
  - Räiskintä
tags:
  - Peli
Alusta(t): [[Sega Genesis]]
Playtime_hrs: 6
Playtime_mins: 48
Pelisarja:
Kehittäjä(t):
Julkaisija(t):
Play_Status: "[[Status - Playing]]"
Rating: 6
---
## Muistiinpanot

