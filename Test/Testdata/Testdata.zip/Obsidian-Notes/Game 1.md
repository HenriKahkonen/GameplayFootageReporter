---
year: 1822
Genret: 
  - Räiskintä
tags:
  - Peli
Alusta: [[Sega Genesis]]
Playtime_hrs:
Playtime_mins:
Pelisarja:
Kehittäjä(t):
Julkaisija(t):
Play_Status: "[[Status - Playing]]"
Rating: 6
---
## Muistiinpanot

