---
year: 1998
Genret:
  - "[[Räiskintä (FPS) -pelit]]"
  - "[[Lisäosat]]"
tags:
  - Peli
Alusta(t):
  - "[[PC]]"
  - Useilla alustoilla
Playtime_hrs:
Playtime_mins:
Pelisarja: "[[Doom-pelisarja]]"
Kehittäjä(t):
  - "[[id Software]]"
Julkaisija(t):
Rating: 4,6
Play_Status: "[[Status - Completed]]"
---
---

**Linkit:**
- [[]]


---

## Yleisesti

- Tarkoituksella väärin nimetty testikansio ja tiedosto
