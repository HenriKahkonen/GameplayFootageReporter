---
year: 2004
Genret:
  - "[[Seikkailupelit]]"
  - "[[Toimintapelit]]"
  - "[[Puzzlepelit]]"
  - "[[Toimintapelit]]"
tags:
  - Peli
Alusta:
  - "[[Game Boy Advance]]"
Playtime_hrs: "14"
Playtime_mins: "19"
Pelisarja: "[[Legend of Zelda -pelisarja]]"
Kehittäjä(t):
  - "[[Capcom Production Studio 1]]"
Julkaisija(t):
  - "[[Nintendo]]"
Play_Status: "[[Status - Playing]]"
Rating: 4
---
## Juoni

- On kulunut 100 vuotta siitä, kun "Picorit" ovat viimeksi tulleet Hyruleen. On picorrien saapumisen juhlapäivän festivaali, ja sen kunniaksi järjestetään turnajaiset
- Turnajaiset voittaa mies, joka palkinnoksi pääsee katsomaan Hyrulen linnassa olevaa Picori-miekkaa. Mies paljastuu ilkeäksi Vaati-velhoksi ja rikkoo pyhän Picori-miekan, joka lukitsee taika-arkkua Hyrulen linnassa. Arkusta lentää hirviöitä ympäri Hyrulea, ja prinsessa Zelda muutetaan kiveksi.
- Jotta Zeldan vangitseva loitsu voidaan purkaa, Picori-miekka on korjattava, ja sitä varten tarvitaan lapsi koska Picorit eivvät näytä itseään aikuisille. Siispä Linkistä on tuleva sankarimme
- On etsittävä ympäri Hyrulea levinneet elementit jotta miekka saadaan korjattua, kyllä sää tiiät tämä on Legend of Zelda -peli